## Entity Types

### `company`

**`{company}`** refers to a business dedicated to commercial enterprise.

### `institution`

**`{institution}`** is the name of an academic institution.

### `location`

**`{location}`** is a fixed physical place, including but not limited to geographical areas like landmasses or and bodies or water, and human-constructed entities like countries, population centres, streets, or buildings.

### `person`

**`{person}`** refers to a person, by name (including honorifics) or pronoun (excluding possessive pronouns).

#### `professor`

**`{professor}`** refers to a professor at an academic institution, by name (including honorifics) or pronoun (excluding possessive pronouns).

#### `role`

Someone may hold a position of **`{role}`** at a company or organization.

## Relation Types

### **`supervise`**

**`{supervisor}`** is the academic supervisor of **`{student}`** at **`{institution}`**.
- **`{supervisor}`**: $1$-$\infty$ entities of type `professor`
- **`{student}`**: $1$-$1$ entities of type `person`
- **`{institution}`**: $0$-$1$ entities of type `institution`

### **`work`**

**`{worker}`** worked as **`{position}`** in **`{organization}`**.
- **`{worker}`**: $1$-$1$ entities of type `person`
- **`{position}`**: $0$-$1$ entities of type `role`
- **`{organization}`**: $1$-$1$ entities of type `company` | `institution`
