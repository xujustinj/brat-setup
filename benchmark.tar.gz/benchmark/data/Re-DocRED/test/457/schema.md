## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`chairperson_of`**

**`{chairperson}`** is the presiding member of the organization, group, or body **`{organization}`**.
- **`{chairperson}`**: $1$-$1$ entities of type `person`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`headquarters_location`**

**`{location}`** is a specific location where **`{organization}`**'s headquarters is or has been situated.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`inception`**

**`{date}`** is the date or point in time when **`{entity}`** was founded or created.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`located_on_landform`**

**`{location}`** is a non-political/administrative entity (i.e., not a province, state, country, etc.) located on the landform **`{landform}`**.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{landform}`**: $1$-$1$ entities of type `location`

### **`on_continent`**

**`{continent}`** is a continent of which **`{item}`** is a part.
- **`{continent}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`record_label_of`**

**`{label}`** is a brand and trademark associated with the marketing of **`{artist}`**.
- **`{label}`**: $1$-$1$ entities of type `organization`
- **`{artist}`**: $1$-$1$ entities of type `organization` | `person`

### **`religion_of`**

**`{religion}`** is the religion of **`{item}`**, where **`{item}`** is a person, organization, or religious building.
- **`{religion}`**: $1$-$1$ entities of type `organization`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`territory_is_claimed_by`**

**`{division}`** is an administrative division that claims control of **`{territory}`**.
- **`{division}`**: $1$-$1$ entities of type `location` | `organization`
- **`{territory}`**: $1$-$1$ entities of type `location`
