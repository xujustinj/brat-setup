## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`died_in`**

**`{place_of_death}`** is the most specific known death location of **`{person}`**.
- **`{place_of_death}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`formed_at`**

**`{location}`** is the location where the group or organization **`{organization}`** was formed.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`has_parent_organization`**

**`{parent}`** is the parent organization of the organization **`{subsidiary}`**.
- **`{parent}`**: $1$-$1$ entities of type `organization`
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`

### **`is_capital_of`**

**`{jurisdiction}`** is a country, state, department, canton, or other administrative division of which **`{capital}`** is the governmental seat.
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`
- **`{capital}`**: $1$-$1$ entities of type `location`

### **`located_in_or_next_to_body_of_water`**

**`{body_of_water}`** is a sea, lake, or river on or next to **`{place}`**.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{place}`**: $1$-$1$ entities of type `location`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`located_on_landform`**

**`{location}`** is a non-political/administrative entity (i.e., not a province, state, country, etc.) located on the landform **`{landform}`**.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{landform}`**: $1$-$1$ entities of type `location`

### **`mouth_of_the_watercourse`**

**`{body_of_water}`** is the body of water to which **`{watercourse}`** drains.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{watercourse}`**: $1$-$1$ entities of type `location`
