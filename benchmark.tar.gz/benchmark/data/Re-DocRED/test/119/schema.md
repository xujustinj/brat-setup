## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`born_in`**

**`{place_of_birth}`** is the most specific known birth location of **`{person}`**.
- **`{place_of_birth}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`died_in`**

**`{place_of_death}`** is the most specific known death location of **`{person}`**.
- **`{place_of_death}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`employer_of`**

**`{employer}`** is a person or organization for which **`{employee}`** works or worked.
- **`{employer}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{employee}`**: $1$-$1$ entities of type `person`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`formed_at`**

**`{location}`** is the location where the group or organization **`{organization}`** was formed.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`replaced_by`**

**`{replacer}`** replaces **`{replaced}`**.
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`

### **`replaces`**

**`{replaced}`** is replaced by **`{replacer}`**.
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`
