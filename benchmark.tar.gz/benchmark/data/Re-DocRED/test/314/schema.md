## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`has_parent_organization`**

**`{parent}`** is the parent organization of the organization **`{subsidiary}`**.
- **`{parent}`**: $1$-$1$ entities of type `organization`
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`

### **`located_in_or_next_to_body_of_water`**

**`{body_of_water}`** is a sea, lake, or river on or next to **`{place}`**.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{place}`**: $1$-$1$ entities of type `location`

### **`mouth_of_the_watercourse`**

**`{body_of_water}`** is the body of water to which **`{watercourse}`** drains.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{watercourse}`**: $1$-$1$ entities of type `location`

### **`operator_of`**

**`{operator}`** is a person or organization that operates **`{operation}`**, where **`{operation}`** is some facility or service.
- **`{operator}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{operation}`**: $1$-$1$ entities of type `location` | `organization`

### **`replaces`**

**`{replaced}`** is replaced by **`{replacer}`**.
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`
