## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`basin_country`**

**`{country}`** is a country that has drainage to/from or borders the body of water **`{body_of_water}`**.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{body_of_water}`**: $1$-$1$ entities of type `location`

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`formed_at`**

**`{location}`** is the location where the group or organization **`{organization}`** was formed.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`founded_by`**

**`{founder}`** is a founder or co-founder of **`{organization}`**, where **`{organization}`** is an organization, religion, or place.
- **`{founder}`**: $1$-$1$ entities of type `organization` | `person`
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_parent_organization`**

**`{parent}`** is the parent organization of the organization **`{subsidiary}`**.
- **`{parent}`**: $1$-$1$ entities of type `organization`
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`

### **`headquarters_location`**

**`{location}`** is a specific location where **`{organization}`**'s headquarters is or has been situated.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`inception`**

**`{date}`** is the date or point in time when **`{entity}`** was founded or created.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`legislative_body_of`**

**`{legislative_body}`** is a legislative body (political institution) governing **`{entity}`**, such as a parliament, legislature, or council.
- **`{legislative_body}`**: $1$-$1$ entities of type `organization`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`record_label_of`**

**`{label}`** is a brand and trademark associated with the marketing of **`{artist}`**.
- **`{label}`**: $1$-$1$ entities of type `organization`
- **`{artist}`**: $1$-$1$ entities of type `organization` | `person`

### **`separated_from`**

**`{child}`** was founded or started by separating from **`{parent}`**.
- **`{child}`**: $1$-$1$ entities of type `location` | `organization`
- **`{parent}`**: $1$-$1$ entities of type `location` | `organization`
