## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`chairperson_of`**

**`{chairperson}`** is the presiding member of the organization, group, or body **`{organization}`**.
- **`{chairperson}`**: $1$-$1$ entities of type `person`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_head_of_government`**

**`{leader}`** is a head of the executive power of the governmental body of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`located_on_landform`**

**`{location}`** is a non-political/administrative entity (i.e., not a province, state, country, etc.) located on the landform **`{landform}`**.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{landform}`**: $1$-$1$ entities of type `location`

### **`member_of_political_party`**

**`{party}`** is a political party of which **`{politician}`** is or has been a member.
- **`{party}`**: $1$-$1$ entities of type `organization`
- **`{politician}`**: $1$-$1$ entities of type `person`
