## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`are_married`**

**`{spouse}`** and **`{spouse}`** are married to each other (e.g., husband, wife, partner).
- **`{spouse}`**: $2$-$2$ entities of type `person`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`founded_by`**

**`{founder}`** is a founder or co-founder of **`{organization}`**, where **`{organization}`** is an organization, religion, or place.
- **`{founder}`**: $1$-$1$ entities of type `organization` | `person`
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_head_of_government`**

**`{leader}`** is a head of the executive power of the governmental body of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`has_mother`**

**`{mother}`** is a female parent (but not stepparent) of **`{child}`**.
- **`{mother}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`on_continent`**

**`{continent}`** is a continent of which **`{item}`** is a part.
- **`{continent}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
