## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`educated_at`**

**`{institution}`** is an educational institution attended by **`{student}`**.
- **`{institution}`**: $1$-$1$ entities of type `location` | `organization`
- **`{student}`**: $1$-$1$ entities of type `person`

### **`formed_at`**

**`{location}`** is the location where the group or organization **`{organization}`** was formed.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`

### **`works_in`**

**`{location}`** is a location where **`{worker}`** was actively participating in employment, business, or other work.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{worker}`**: $1$-$1$ entities of type `person`
