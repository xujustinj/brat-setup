## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`followed_by`**

**`{follower}`** is the immediately following item in some series of which **`{predecessor}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`

### **`founded_by`**

**`{founder}`** is a founder or co-founder of **`{organization}`**, where **`{organization}`** is an organization, religion, or place.
- **`{founder}`**: $1$-$1$ entities of type `organization` | `person`
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_mother`**

**`{mother}`** is a female parent (but not stepparent) of **`{child}`**.
- **`{mother}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`has_unemployment_rate`**

**`{rate}`** is the portion of the workforce population that is not employed in **`{jurisdiction}`**.
- **`{rate}`**: $1$-$1$ entities of type `number`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`is_capital_of`**

**`{jurisdiction}`** is a country, state, department, canton, or other administrative division of which **`{capital}`** is the governmental seat.
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`
- **`{capital}`**: $1$-$1$ entities of type `location`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_or_next_to_body_of_water`**

**`{body_of_water}`** is a sea, lake, or river on or next to **`{place}`**.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{place}`**: $1$-$1$ entities of type `location`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`located_on_landform`**

**`{location}`** is a non-political/administrative entity (i.e., not a province, state, country, etc.) located on the landform **`{landform}`**.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{landform}`**: $1$-$1$ entities of type `location`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`
