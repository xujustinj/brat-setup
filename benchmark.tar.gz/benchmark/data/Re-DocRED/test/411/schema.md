## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`are_married`**

**`{spouse}`** and **`{spouse}`** are married to each other (e.g., husband, wife, partner).
- **`{spouse}`**: $2$-$2$ entities of type `person`

### **`child_of`**

**`{parent}`** has **`{child}`** in their family as their offspring son or daughter, regardless of **`{child}`**'s age.
- **`{parent}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`educated_at`**

**`{institution}`** is an educational institution attended by **`{student}`**.
- **`{institution}`**: $1$-$1$ entities of type `location` | `organization`
- **`{student}`**: $1$-$1$ entities of type `person`

### **`followed_by`**

**`{follower}`** is the immediately following item in some series of which **`{predecessor}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_father`**

**`{father}`** is a male parent (but not stepparent) of **`{child}`**.
- **`{father}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`has_head_of_state`**

**`{leader}`** is an official with the highest formal authority in the country or state of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`has_mother`**

**`{mother}`** is a female parent (but not stepparent) of **`{child}`**.
- **`{mother}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_or_next_to_body_of_water`**

**`{body_of_water}`** is a sea, lake, or river on or next to **`{place}`**.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{place}`**: $1$-$1$ entities of type `location`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`replaced_by`**

**`{replacer}`** replaces **`{replaced}`**.
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`

### **`replaces`**

**`{replaced}`** is replaced by **`{replacer}`**.
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`

### **`residence_of`**

**`{residence}`** is a place where **`{resident}`** is, or has been, a resident.
- **`{residence}`**: $1$-$1$ entities of type `location`
- **`{resident}`**: $1$-$1$ entities of type `person`
