## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`employer_of`**

**`{employer}`** is a person or organization for which **`{employee}`** works or worked.
- **`{employer}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{employee}`**: $1$-$1$ entities of type `person`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_head_of_government`**

**`{leader}`** is a head of the executive power of the governmental body of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`has_head_of_state`**

**`{leader}`** is an official with the highest formal authority in the country or state of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`has_unemployment_rate`**

**`{rate}`** is the portion of the workforce population that is not employed in **`{jurisdiction}`**.
- **`{rate}`**: $1$-$1$ entities of type `number`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`on_continent`**

**`{continent}`** is a continent of which **`{item}`** is a part.
- **`{continent}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`replaces`**

**`{replaced}`** is replaced by **`{replacer}`**.
- **`{replaced}`**: $1$-$1$ entities of type `location` | `organization`
- **`{replacer}`**: $1$-$1$ entities of type `location` | `organization`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`
