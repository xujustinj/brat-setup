## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`are_married`**

**`{spouse}`** and **`{spouse}`** are married to each other (e.g., husband, wife, partner).
- **`{spouse}`**: $2$-$2$ entities of type `person`

### **`basin_country`**

**`{country}`** is a country that has drainage to/from or borders the body of water **`{body_of_water}`**.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{body_of_water}`**: $1$-$1$ entities of type `location`

### **`died_in`**

**`{place_of_death}`** is the most specific known death location of **`{person}`**.
- **`{place_of_death}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`follows`**

**`{predecessor}`** is the immediately preceding item in some series of which **`{follower}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`inception`**

**`{date}`** is the date or point in time when **`{entity}`** was founded or created.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`
