## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`born_in`**

**`{place_of_birth}`** is the most specific known birth location of **`{person}`**.
- **`{place_of_birth}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`member_of_sports_team`**

**`{team}`** is a sports team or club that **`{member}`** currently represents or formerly represented.
- **`{team}`**: $1$-$1$ entities of type `location` | `organization`
- **`{member}`**: $1$-$1$ entities of type `person`

### **`operator_of`**

**`{operator}`** is a person or organization that operates **`{operation}`**, where **`{operation}`** is some facility or service.
- **`{operator}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{operation}`**: $1$-$1$ entities of type `location` | `organization`

### **`religion_of`**

**`{religion}`** is the religion of **`{item}`**, where **`{item}`** is a person, organization, or religious building.
- **`{religion}`**: $1$-$1$ entities of type `organization`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`

### **`sister_city_of`**

**`{city}`** and **`{city}`** are twin towns, sister cities, twinned municipalities, or any other pair of localities that have a partnership or cooperative agreement, either legally or informally acknowledged by their governments.
- **`{city}`**: $2$-$2$ entities of type `location`
