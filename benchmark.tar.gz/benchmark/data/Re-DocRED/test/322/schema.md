## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`followed_by`**

**`{follower}`** is the immediately following item in some series of which **`{predecessor}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_father`**

**`{father}`** is a male parent (but not stepparent) of **`{child}`**.
- **`{father}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`has_parent_organization`**

**`{parent}`** is the parent organization of the organization **`{subsidiary}`**.
- **`{parent}`**: $1$-$1$ entities of type `organization`
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`

### **`headquarters_location`**

**`{location}`** is a specific location where **`{organization}`**'s headquarters is or has been situated.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`is_influenced_by`**

The person **`{influenced}`** is informed by **`{influencer}`**, e.g., "Heidegger was influenced by Aristotle".
- **`{influenced}`**: $1$-$1$ entities of type `person`
- **`{influencer}`**: $1$-$1$ entities of type `person`

### **`legislative_body_of`**

**`{legislative_body}`** is a legislative body (political institution) governing **`{entity}`**, such as a parliament, legislature, or council.
- **`{legislative_body}`**: $1$-$1$ entities of type `organization`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`owned_by`**

**`{owner}`** is an owner of **`{item}`**.
- **`{owner}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`
