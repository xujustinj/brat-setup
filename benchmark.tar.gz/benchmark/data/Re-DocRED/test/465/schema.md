## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`record_label_of`**

**`{label}`** is a brand and trademark associated with the marketing of **`{artist}`**.
- **`{label}`**: $1$-$1$ entities of type `organization`
- **`{artist}`**: $1$-$1$ entities of type `organization` | `person`

### **`residence_of`**

**`{residence}`** is a place where **`{resident}`** is, or has been, a resident.
- **`{residence}`**: $1$-$1$ entities of type `location`
- **`{resident}`**: $1$-$1$ entities of type `person`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`

### **`sports_league_of`**

**`{league}`** is a league in which the team or player **`{participant}`** plays or has played in.
- **`{league}`**: $1$-$1$ entities of type `organization`
- **`{participant}`**: $1$-$1$ entities of type `location` | `organization` | `person`
