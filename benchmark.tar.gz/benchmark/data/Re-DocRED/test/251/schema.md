## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`are_married`**

**`{spouse}`** and **`{spouse}`** are married to each other (e.g., husband, wife, partner).
- **`{spouse}`**: $2$-$2$ entities of type `person`

### **`employer_of`**

**`{employer}`** is a person or organization for which **`{employee}`** works or worked.
- **`{employer}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{employee}`**: $1$-$1$ entities of type `person`

### **`founded_by`**

**`{founder}`** is a founder or co-founder of **`{organization}`**, where **`{organization}`** is an organization, religion, or place.
- **`{founder}`**: $1$-$1$ entities of type `organization` | `person`
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`inception`**

**`{date}`** is the date or point in time when **`{entity}`** was founded or created.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`member_of_sports_team`**

**`{team}`** is a sports team or club that **`{member}`** currently represents or formerly represented.
- **`{team}`**: $1$-$1$ entities of type `location` | `organization`
- **`{member}`**: $1$-$1$ entities of type `person`

### **`operator_of`**

**`{operator}`** is a person or organization that operates **`{operation}`**, where **`{operation}`** is some facility or service.
- **`{operator}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{operation}`**: $1$-$1$ entities of type `location` | `organization`

### **`owned_by`**

**`{owner}`** is an owner of **`{item}`**.
- **`{owner}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
