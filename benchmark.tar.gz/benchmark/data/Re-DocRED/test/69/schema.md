## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`are_married`**

**`{spouse}`** and **`{spouse}`** are married to each other (e.g., husband, wife, partner).
- **`{spouse}`**: $2$-$2$ entities of type `person`

### **`born_in`**

**`{place_of_birth}`** is the most specific known birth location of **`{person}`**.
- **`{place_of_birth}`**: $1$-$1$ entities of type `location`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`member_of`**

**`{organization}`** is an organization or club to which **`{member}`** belongs, where **`{organization}`** is not an ethnic or social group, nor is it a position held by **`{member}`**.
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`
- **`{member}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`record_label_of`**

**`{label}`** is a brand and trademark associated with the marketing of **`{artist}`**.
- **`{label}`**: $1$-$1$ entities of type `organization`
- **`{artist}`**: $1$-$1$ entities of type `organization` | `person`

### **`separated_from`**

**`{child}`** was founded or started by separating from **`{parent}`**.
- **`{child}`**: $1$-$1$ entities of type `location` | `organization`
- **`{parent}`**: $1$-$1$ entities of type `location` | `organization`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`
