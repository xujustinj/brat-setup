## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`chairperson_of`**

**`{chairperson}`** is the presiding member of the organization, group, or body **`{organization}`**.
- **`{chairperson}`**: $1$-$1$ entities of type `person`
- **`{organization}`**: $1$-$1$ entities of type `organization`

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`founded_by`**

**`{founder}`** is a founder or co-founder of **`{organization}`**, where **`{organization}`** is an organization, religion, or place.
- **`{founder}`**: $1$-$1$ entities of type `organization` | `person`
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_head_of_state`**

**`{leader}`** is an official with the highest formal authority in the country or state of **`{jurisdiction}`**.
- **`{leader}`**: $1$-$1$ entities of type `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`legislative_body_of`**

**`{legislative_body}`** is a legislative body (political institution) governing **`{entity}`**, such as a parliament, legislature, or council.
- **`{legislative_body}`**: $1$-$1$ entities of type `organization`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`member_of`**

**`{organization}`** is an organization or club to which **`{member}`** belongs, where **`{organization}`** is not an ethnic or social group, nor is it a position held by **`{member}`**.
- **`{organization}`**: $1$-$1$ entities of type `location` | `organization`
- **`{member}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`religion_of`**

**`{religion}`** is the religion of **`{item}`**, where **`{item}`** is a person, organization, or religious building.
- **`{religion}`**: $1$-$1$ entities of type `organization`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`works_in`**

**`{location}`** is a location where **`{worker}`** was actively participating in employment, business, or other work.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{worker}`**: $1$-$1$ entities of type `person`
