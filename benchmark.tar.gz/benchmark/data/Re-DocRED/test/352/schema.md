## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`legislative_body_of`**

**`{legislative_body}`** is a legislative body (political institution) governing **`{entity}`**, such as a parliament, legislature, or council.
- **`{legislative_body}`**: $1$-$1$ entities of type `organization`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`member_of_sports_team`**

**`{team}`** is a sports team or club that **`{member}`** currently represents or formerly represented.
- **`{team}`**: $1$-$1$ entities of type `location` | `organization`
- **`{member}`**: $1$-$1$ entities of type `person`

### **`works_in`**

**`{location}`** is a location where **`{worker}`** was actively participating in employment, business, or other work.
- **`{location}`**: $1$-$1$ entities of type `location`
- **`{worker}`**: $1$-$1$ entities of type `person`
