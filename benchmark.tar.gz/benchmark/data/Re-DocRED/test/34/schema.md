## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`applies_to_jurisdiction`**

**`{item}`** (e.g., an institution, law, public office) belongs to, has power over, or applies to the territorial jurisdiction (e.g., country, state, municipality) of **`{jurisdiction}`**.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`child_of`**

**`{parent}`** has **`{child}`** in their family as their offspring son or daughter, regardless of **`{child}`**'s age.
- **`{parent}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`educated_at`**

**`{institution}`** is an educational institution attended by **`{student}`**.
- **`{institution}`**: $1$-$1$ entities of type `location` | `organization`
- **`{student}`**: $1$-$1$ entities of type `person`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`followed_by`**

**`{follower}`** is the immediately following item in some series of which **`{predecessor}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`

### **`follows`**

**`{predecessor}`** is the immediately preceding item in some series of which **`{follower}`** is part, but **`{follower}`** does not replace **`{predecessor}`**.
- **`{predecessor}`**: $1$-$1$ entities of type `location` | `organization`
- **`{follower}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`inception`**

**`{date}`** is the date or point in time when **`{entity}`** was founded or created.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`legislative_body_of`**

**`{legislative_body}`** is a legislative body (political institution) governing **`{entity}`**, such as a parliament, legislature, or council.
- **`{legislative_body}`**: $1$-$1$ entities of type `organization`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_or_next_to_body_of_water`**

**`{body_of_water}`** is a sea, lake, or river on or next to **`{place}`**.
- **`{body_of_water}`**: $1$-$1$ entities of type `location`
- **`{place}`**: $1$-$1$ entities of type `location`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`military_branch_of`**

**`{branch}`** is a branch of the military to which **`{unit}`** belongs, where **`{unit}`** is a military unit, office, or person.
- **`{branch}`**: $1$-$1$ entities of type `organization`
- **`{unit}`**: $1$-$1$ entities of type `organization` | `person`

### **`operator_of`**

**`{operator}`** is a person or organization that operates **`{operation}`**, where **`{operation}`** is some facility or service.
- **`{operator}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{operation}`**: $1$-$1$ entities of type `location` | `organization`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
