## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`child_of`**

**`{parent}`** has **`{child}`** in their family as their offspring son or daughter, regardless of **`{child}`**'s age.
- **`{parent}`**: $1$-$1$ entities of type `person`
- **`{child}`**: $1$-$1$ entities of type `person`

### **`date_of_birth`**

**`{date}`** is the date on which **`{person}`** was born.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`date_of_death`**

**`{date}`** is the date on which **`{person}`** died.
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{person}`**: $1$-$1$ entities of type `person`

### **`employer_of`**

**`{employer}`** is a person or organization for which **`{employee}`** works or worked.
- **`{employer}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{employee}`**: $1$-$1$ entities of type `person`

### **`is_citizen_of`**

**`{country}`** is a country that recognizes **`{citizen}`** as its citizen.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{citizen}`**: $1$-$1$ entities of type `person`

### **`record_label_of`**

**`{label}`** is a brand and trademark associated with the marketing of **`{artist}`**.
- **`{label}`**: $1$-$1$ entities of type `organization`
- **`{artist}`**: $1$-$1$ entities of type `organization` | `person`
