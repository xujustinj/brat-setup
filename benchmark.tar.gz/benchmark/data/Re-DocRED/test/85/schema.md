## Entity Types

### `location`

**`{location}`** is a physical place, which may be a geographically-defined location (e.g., mountain, body of water), a politically defined location (e.g., country, street), or a physical facility (e.g., stadium, airport).

### `number`

**`{number}`** is a numerical quantity, including percentages or monetary values.

### `organization`

**`{organization}`** is an organization (e.g., company, university, institution, political or religious group).

### `person`

**`{person}`** is a real or fictional person.

### `time`

**`{time}`** is an absolute or relative date or period of time.

## Relation Types

### **`contains_administrative_territorial_entity`**

**`{subdivision}`** is a direct subdivision of the administrative territorial entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{subdivision}`**: $1$-$1$ entities of type `location`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`ended`**

**`{date}`** is the date or point in time on which **`{entity}`** was dissolved (if **`{entity}`** is an organization), disappeared, or demolished (if **`{entity}`** is a building).
- **`{date}`**: $1$-$1$ entities of type `time`
- **`{entity}`**: $1$-$1$ entities of type `location` | `organization`

### **`ethnicity_of`**

**`{person}`** claims that their ethnicity is **`{ethnicity}`**, or scholars widely agree on **`{ethnicity}`** being **`{person}`**'s ethnicity, or **`{person}`** is fictional and is portrayed as being of **`{ethnicity}`**.
- **`{person}`**: $1$-$1$ entities of type `person`
- **`{ethnicity}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_country`**

**`{country}`** is the sovereign state that **`{item}`** is in.
- **`{country}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`has_part`**

**`{part}`** is a part of **`{whole}`**.
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`

### **`located_in_territory`**

**`{item}`** is located on the territory of the administrative entity **`{jurisdiction}`**, where **`{jurisdiction}`** is a division (e.g., state, province, city, region, district) of a sovereign state.
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`
- **`{jurisdiction}`**: $1$-$1$ entities of type `location`

### **`military_branch_of`**

**`{branch}`** is a branch of the military to which **`{unit}`** belongs, where **`{unit}`** is a military unit, office, or person.
- **`{branch}`**: $1$-$1$ entities of type `organization`
- **`{unit}`**: $1$-$1$ entities of type `organization` | `person`

### **`on_continent`**

**`{continent}`** is a continent of which **`{item}`** is a part.
- **`{continent}`**: $1$-$1$ entities of type `location`
- **`{item}`**: $1$-$1$ entities of type `location` | `organization`

### **`part_of`**

**`{whole}`** has **`{part}`** as a part.
- **`{whole}`**: $1$-$1$ entities of type `location` | `organization`
- **`{part}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`sibling_of`**

**`{sibling}`** is a sibling (not sibling-in-law or step-sibling) of **`{sibling}`**.
- **`{sibling}`**: $2$-$2$ entities of type `person`

### **`sports_league_of`**

**`{league}`** is a league in which the team or player **`{participant}`** plays or has played in.
- **`{league}`**: $1$-$1$ entities of type `organization`
- **`{participant}`**: $1$-$1$ entities of type `location` | `organization` | `person`

### **`subsidiary_of`**

**`{subsidiary}`** is a subsidiary of the parent company or organization **`{parent}`**.
- **`{subsidiary}`**: $1$-$1$ entities of type `organization`
- **`{parent}`**: $1$-$1$ entities of type `organization`
