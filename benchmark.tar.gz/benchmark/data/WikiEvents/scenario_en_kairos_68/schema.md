## Entity Types

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

## Relation Types

### **`exchange`**

**`{giver}`** gave **`{entity}`** to **`{recipient}`** in exchange for **`{payment}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{entity}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `vehicle`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{payment}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `vehicle`

### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `vehicle`

### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `vehicle`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`release`**

**`{defendant}`** was released or paroled by the judge or court **`{court}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`work`**

**`{employer}`** is an organization in which **`{employee}`** worked.
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{employee}`**: $0$-$\infty$ entities of type `person`
