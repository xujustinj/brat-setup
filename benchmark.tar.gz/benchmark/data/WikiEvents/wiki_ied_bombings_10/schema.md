## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attack`**

**`{attacker}`** used **`{instrument}`** to attack **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `vehicle` | `weapon`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`damage`**

**`{artifact}`** was damaged, but not destroyed, by **`{damager}`** using **`{instrument}`**.
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `location` | `product` | `vehicle` | `weapon`
- **`{damager}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `vehicle` | `weapon`

### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`illegally_transport`**

**`{transporter}`** illegally transported themselves or **`{occupant}`** in **`{vehicle}`** from **`{origin}`** place to **`{destination}`** place, such as by smuggling, trespassing, or intruding.
- **`{transporter}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`move`**

**`{mover}`** moved from **`{origin}`** to **`{destination}`**.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`produce`**

**`{producer}`** used **`{components}`** as a component in the production, manufacturing, or assembly of **`{artifact}`**.
- **`{producer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{components}`**: $0$-$\infty$ entities of type `product` | `vehicle` | `weapon`
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`

### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`trial`**

**`{defendant}`** was tried for a crime by **`{prosecutor}`** before **`{court}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{prosecutor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
