## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

## Relation Types

### **`broadcast`**

**`{communicator}`** broadcasted a one-way communication containing information about **`{topic}`** to **`{recipient}`**.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `person` | `product` | `value`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`illegally_transport`**

Transporting **`{occupant}`** from **`{origin}`** to **`{destination}`** was illegal.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `person` | `product`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`transport`**

**`{occupant}`** was transported from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `person` | `product`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`work`**

**`{employer}`** is an organization in which **`{employee}`** worked.
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{employee}`**: $0$-$\infty$ entities of type `person`
