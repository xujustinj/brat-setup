## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`broadcast`**

**`{communicator}`** broadcasted a one-way communication containing information about **`{topic}`** to **`{recipient}`**.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `value` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`communicate`**

**`{participant}`** communicated by any means (one-way or two-way) with **`{participant}`**.
- **`{participant}`**: $2$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`dismantle`**

**`{instrument}`** was used by **`{dismantler}`** to dismantle **`{artifact}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `vehicle`
- **`{dismantler}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`

### **`evacuate`**

**`{occupant}`** evacuated, escaped, or retreated from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `person`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`illegally_transport`**

**`{transporter}`** illegally transported themselves or **`{occupant}`** in **`{vehicle}`** from **`{origin}`** place to **`{destination}`** place, such as by smuggling, trespassing, or intruding.
- **`{transporter}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`investigate`**

**`{investigator}`** investigated **`{defendant}`** for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{investigator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`meet`**

**`{participant}`** met with **`{participant}`** at **`{place}`**.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`move`**

**`{mover}`** moved from **`{origin}`** to **`{destination}`**.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`occupant`**

**`{occupant}`** was transported using **`{vehicle}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`threaten`**

**`{communicator}`** communicated (by any means) a threat, coersion, or provocation to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`transport`**

**`{transporter}`** transported themselves or **`{occupant}`** in **`{vehicle}`** from **`{origin}`** place to **`{destination}`** place.
- **`{transporter}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
