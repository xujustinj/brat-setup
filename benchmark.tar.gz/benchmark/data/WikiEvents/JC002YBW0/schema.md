## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attack`**

**`{attacker}`** attacked **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where the attack occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`charge`**

**`{defendant}`** was charged before **`{court}`** with a crime by **`{prosecutor}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{prosecutor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`communicate`**

**`{communicator}`** sent (e.g., broadcasted, spoke, wrote) any communication to **`{recipient}`** about **`{topic}`**.
- **`{communicator}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `information` | `payment` | `product` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`exchange`**

**`{giver}`** gave **`{entity}`** to **`{recipient}`** in exchange for **`{payment}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{entity}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `product` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{payment}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `product` | `vehicle` | `weapon`

### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{explosive}`**: $0$-$\infty$ entities of type `product` | `weapon`

### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `payment` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`

### **`identify`**

**`{identifier}`** identified **`{object}`** as **`{role}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{identifier}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{object}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{role}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`interfere`**

**`{impeder}`** impeded or interfered with some event, and **`{place}`** is the most specific given location where this occurred.
- **`{impeder}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`meet`**

**`{participant}`** met with **`{participant}`** at **`{place}`**.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`observe`**

**`{entity}`** was observed by **`{observer}`**.
- **`{entity}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{observer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`obstruct`**

**`{occupant}`** was prevented from moving from **`{origin}`** to **`{destination}`** by **`{preventer}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{preventer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`possess`**

At some point in the past or present, **`{owner}`** had possession of **`{artifact}`**.
- **`{owner}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $1$-$\infty$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `product` | `vehicle` | `weapon`

### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`start_position`**

**`{employee}`** started working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`threaten`**

**`{communicator}`** communicated (by any means) a threat, coersion, or provocation to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`work`**

**`{employee}`** worked in the position of **`{position}`**.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
