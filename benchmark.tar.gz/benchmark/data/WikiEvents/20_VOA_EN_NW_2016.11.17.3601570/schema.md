## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`charge`**

**`{defendant}`** was charged before **`{court}`** with a crime by **`{prosecutor}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{prosecutor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`crime`**

**`{perpetrator}`** committed a crime against **`{victim}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{perpetrator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`destroy`**

**`{artifact}`** was destroyed by **`{destroyer}`**.
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `location` | `product` | `vehicle` | `weapon`
- **`{destroyer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`detain`**

**`{detainee}`** was arrested or jailed by **`{jailer}`**.
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`dismantle`**

**`{artifact}`** was dismantled into **`{components}`** by **`{dismantler}`**.
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{components}`**: $0$-$\infty$ entities of type `product`
- **`{dismantler}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{explosive}`**: $0$-$\infty$ entities of type `product` | `weapon`

### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`injure`**

**`{victim}`** was injured in **`{body_part}`** body part by **`{injurer}`** using **`{instrument}`**.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{body_part}`**: $0$-$\infty$ entities of type `body`
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`

### **`medical_intervention`**

**`{patient}`** received treatment from **`{treater}`** for a medical issue.
- **`{patient}`**: $0$-$\infty$ entities of type `person`
- **`{treater}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`research`**

**`{researcher}`** researched **`{subject}`**, and **`{place}`** is the most specific given location where the research occurred.
- **`{researcher}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{subject}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`trial`**

**`{prosecutor}`** tried **`{defendant}`** before **`{court}`** court or judge for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{prosecutor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
