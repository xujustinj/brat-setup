## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`communicate`**

**`{communicator}`** sent (e.g., broadcasted, spoke, wrote) any communication to **`{recipient}`** about **`{topic}`**.
- **`{communicator}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `vehicle` | `weapon`

### **`crash`**

**`{vehicle}`** vehicle crashed into **`{object}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`
- **`{object}`**: $0$-$\infty$ entities of type `facility` | `location` | `person` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`detain`**

**`{detainee}`** was arrested or jailed by **`{jailer}`**.
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`evacuate`**

**`{occupant}`** evacuated, escaped, or retreated from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `person`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{explosive}`**: $0$-$\infty$ entities of type `weapon`

### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `payment` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `payment` | `person` | `vehicle` | `weapon`

### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `payment` | `vehicle` | `weapon`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `vehicle` | `weapon`

### **`sentence`**

**`{court}`** court or judge sentenced **`{defendant}`** for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`threaten`**

**`{communicator}`** communicated (by any means) a threat, coersion, or provocation to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `vehicle` | `weapon`
