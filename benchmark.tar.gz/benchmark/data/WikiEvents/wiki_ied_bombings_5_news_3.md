## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`attack`**

**`{attacker}`** attacked **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`correspond`**

**`{participant}`** corresponded remotely with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`body`** | **`entity`** | **`facility`** | **`location`** | **`organization`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`crash`**

**`{object}`** was struck by **`{vehicle}`**.
- **`{object}`**: 0-∞ entities of type **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{vehicle}`**: 0-∞ entities of type **`vehicle`**

#### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{detainee}`**: 0-∞ entities of type **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`body`** | **`entity`** | **`facility`** | **`location`** | **`organization`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`dismantle`**

**`{dismantler}`** dismantled **`{artifact}`**.
- **`{dismantler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`explode`**

**`{attacker}`** detonated or exploded **`{explosive}`** explosive device using **`{instrument}`** to attack **`{target}`** target, and **`{place}`** is the most specific given location where the explosion occurred.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{explosive}`**: 0-∞ entities of type **`product`** | **`weapon`**
- **`{instrument}`**: 0-∞ entities of type **`product`** | **`weapon`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`injure`**

**`{victim}`** was injured in **`{body_part}`** body part.
- **`{victim}`**: 0-∞ entities of type **`person`**
- **`{body_part}`**: 0-∞ entities of type **`body`**

#### **`meet`**

**`{participant}`** met with **`{participant}`** at **`{place}`**.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`body`** | **`entity`** | **`facility`** | **`location`** | **`organization`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{recipient}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`body`** | **`entity`** | **`facility`** | **`location`** | **`organization`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`trial`**

**`{defendant}`** was tried for a crime by **`{prosecutor}`** before **`{court}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{prosecutor}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
