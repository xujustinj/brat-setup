## Entity Types

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attack`**

**`{attacker}`** attacked **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where the attack occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: $0$-$\infty$ entities of type `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`charge`**

**`{prosecutor}`** charged or indicted **`{defendant}`** before **`{court}`** court or judge for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{prosecutor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`

### **`meet`**

**`{participant}`** met face-to-face with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic, and **`{place}`** is the most specific given location where this meeting occurred.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`possess`**

At some point in the past or present, **`{owner}`** had possession of **`{artifact}`**.
- **`{owner}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $1$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `organization` | `product` | `vehicle` | `weapon`

### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`start_position`**

**`{employee}`** started working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
