## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`attack`**

**`{attacker}`** used **`{instrument}`** to attack **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`vehicle`** | **`weapon`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`vehicle`** | **`weapon`**

#### **`charge`**

**`{defendant}`** was charged before **`{court}`** with a crime by **`{prosecutor}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{prosecutor}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`communicate_bidirectional`**

**`{participant}`** communicated by any means (one-way or two-way) with **`{participant}`**.
- **`{participant}`**: 2-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`convict`**

**`{defendant}`** was convicted of a crime by **`{court}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`damage`**

**`{damager}`** damaged **`{artifact}`**, but did not destroy it.
- **`{damager}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`location`** | **`vehicle`** | **`weapon`**

#### **`destroy`**

**`{artifact}`** was destroyed by **`{destroyer}`**.
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`location`** | **`vehicle`** | **`weapon`**
- **`{destroyer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`disable`**

**`{artifact}`** was defused or disabled by **`{disabler}`**.
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`information`** | **`vehicle`** | **`weapon`**
- **`{disabler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`explode`**

**`{attacker}`** used **`{instrument}`** to cause the explosion of **`{explosive}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`weapon`**
- **`{explosive}`**: 0-∞ entities of type **`weapon`**

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`vehicle`** | **`weapon`**

#### **`illegally_transport`**

Transporting **`{occupant}`** from **`{origin}`** to **`{destination}`** was illegal.
- **`{occupant}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`person`** | **`vehicle`** | **`weapon`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`facility`** | **`vehicle`** | **`weapon`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`person`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`release`**

**`{defendant}`** was released or paroled by the judge or court **`{court}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`sentence`**

**`{court}`** court or judge sentenced **`{defendant}`** for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
