## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`attack`**

**`{attacker}`** used **`{instrument}`** to attack **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`vehicle`** | **`weapon`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`location`** | **`person`** | **`vehicle`** | **`weapon`**

#### **`communicate`**

**`{recipient}`** received (e.g., watched, heard, read) any communication from **`{communicator}`**.
- **`{recipient}`**: 1-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{communicator}`**: 1-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`communicate_bidirectional`**

**`{participant}`** communicated by any means (one-way or two-way) with **`{participant}`**.
- **`{participant}`**: 2-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`convict`**

**`{court}`** court or judge convicted **`{defendant}`** of a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`location`**

#### **`destroy`**

**`{destroyer}`** destroyed **`{artifact}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{destroyer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`location`** | **`payment`** | **`vehicle`** | **`weapon`**
- **`{instrument}`**: 0-∞ entities of type **`vehicle`** | **`weapon`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`location`**

#### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`disable`**

**`{artifact}`** was defused or disabled by **`{disabler}`**.
- **`{artifact}`**: 0-∞ entities of type **`information`** | **`vehicle`** | **`weapon`**
- **`{disabler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: 0-∞ entities of type **`entity`** | **`location`** | **`person`** | **`vehicle`** | **`weapon`**
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{explosive}`**: 0-∞ entities of type **`weapon`**

#### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: 0-∞ entities of type **`payment`** | **`vehicle`** | **`weapon`**
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`location`** | **`payment`** | **`person`** | **`vehicle`** | **`weapon`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`body`** | **`condition`** | **`entity`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`vehicle`** | **`weapon`**
