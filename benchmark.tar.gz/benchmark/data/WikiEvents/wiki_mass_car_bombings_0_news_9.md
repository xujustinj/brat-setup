## Entity Types

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

## Relation Types

#### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: 0-∞ entities of type **`facility`** | **`location`** | **`payment`** | **`person`** | **`vehicle`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`communicate`**

**`{recipient}`** received (e.g., watched, heard, read) any communication from **`{communicator}`**.
- **`{recipient}`**: 1-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{communicator}`**: 1-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`communicate_bidirectional`**

**`{participant}`** communicated (one-way or two-way) by any means with **`{participant}`** about **`{topic}`**.
- **`{participant}`**: 2-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`value`** | **`vehicle`**

#### **`crime`**

**`{perpetrator}`** committed a crime against **`{victim}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{perpetrator}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`demonstrate`**

**`{demonstrator}`** was in a demonstration for **`{topic}`** topic against **`{target}`**, with potential involvement of **`{regulator}`** police or military.
- **`{demonstrator}`**: 0-∞ entities of type **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`value`** | **`vehicle`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{regulator}`**: 0-∞ entities of type **`organization`** | **`person`**

#### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{detainee}`**: 0-∞ entities of type **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: 0-∞ entities of type **`person`**
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`disable`**

**`{instrument}`** was used by **`{disabler}`** to defuse or disable **`{artifact}`**.
- **`{instrument}`**: 0-∞ entities of type **`information`** | **`vehicle`**
- **`{disabler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`information`** | **`vehicle`**

#### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`value`** | **`vehicle`**

#### **`explode`**

**`{attacker}`** used **`{instrument}`** to cause the explosion of **`{explosive}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type 
- **`{explosive}`**: 0-∞ entities of type 

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage to or at **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`vehicle`**
- **`{instrument}`**: 0-∞ entities of type **`facility`** | **`payment`** | **`vehicle`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`interfere`**

**`{impeder}`** impeded or interfered with some event, and **`{place}`** is the most specific given location where this occurred.
- **`{impeder}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`value`** | **`vehicle`**

#### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{recipient}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`value`** | **`vehicle`**

#### **`transport`**

**`{occupant}`** was transported from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: 0-∞ entities of type **`facility`** | **`location`** | **`payment`** | **`person`** | **`vehicle`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
