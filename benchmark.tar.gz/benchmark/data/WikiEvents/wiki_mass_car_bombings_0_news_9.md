## Entity Types

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`broadcast`**

**`{communicator}`** remotely broadcasted a one-way communication to **`{recipient}`** containing information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic using **`{instrument}`**.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `information` | `product`

### **`communicate`**

**`{communicator}`** sent (e.g., broadcasted, spoke, wrote) any communication to **`{recipient}`** about **`{topic}`**.
- **`{communicator}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $1$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`defeat`**

**`{victor}`** defeated **`{loser}`** in a conflict or election, and **`{place}`** is the most specific given location where this occurred.
- **`{victor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{loser}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`request`**

**`{communicator}`** communicated (by any means) a request, command, or order to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`research`**

**`{researcher}`** researched **`{subject}`**, and **`{place}`** is the most specific given location where the research occurred.
- **`{researcher}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{subject}`**: $0$-$\infty$ entities of type `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`transport`**

**`{transporter}`** transported themselves or **`{occupant}`** in **`{vehicle}`** from **`{origin}`** place to **`{destination}`** place.
- **`{transporter}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{occupant}`**: $0$-$\infty$ entities of type `facility` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
