## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`attack`**

**`{attacker}`** attacked **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where the attack occurred.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{instrument}`**: 0-∞ entities of type **`product`** | **`vehicle`** | **`weapon`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`crash`**

**`{object}`** was struck by **`{vehicle}`**.
- **`{object}`**: 0-∞ entities of type **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{vehicle}`**: 0-∞ entities of type **`vehicle`**

#### **`crime`**

**`{victim}`** is the victim of a crime committed by **`{perpetrator}`**.
- **`{victim}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{perpetrator}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{detainee}`**: 0-∞ entities of type **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`identify`**

**`{identifier}`** identified **`{object}`** as **`{role}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{identifier}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{object}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{role}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`interfere`**

**`{impeder}`** impeded or interfered with some event, and **`{place}`** is the most specific given location where this occurred.
- **`{impeder}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`observe`**

**`{observer}`** used **`{instrument}`** to observe **`{entity}`**.
- **`{observer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`product`**
- **`{entity}`**: 0-∞ entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`obstruct`**

**`{preventer}`** prevents **`{transporter}`** from entering **`{destination}`** place from **`{origin}`** place to transport **`{occupant}`** using **`{vehicle}`** vehicle.
- **`{preventer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{transporter}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{occupant}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{vehicle}`**: 0-∞ entities of type **`vehicle`**

#### **`outbreak`**

**`{disease}`** broke out among people or animals located most-specifically in **`{place}`**.
- **`{disease}`**: 0-∞ entities of type **`condition`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`** | **`vehicle`**

#### **`possess`**

At some point in the past or present, **`{owner}`** had possession of **`{artifact}`**.
- **`{owner}`**: 1-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 1-∞ entities of type **`body`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`trial`**

**`{defendant}`** was tried for a crime by **`{prosecutor}`** before **`{court}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{prosecutor}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`work`**

**`{employee}`** held the position of **`{position}`** at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: 0-∞ entities of type **`person`**
- **`{position}`**: 0-∞ entities of type **`title`**
- **`{employer}`**: 0-∞ entities of type **`entity`** | **`organization`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
