## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`injure`**

**`{victim}`** was injured in **`{body_part}`** body part.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{body_part}`**: $0$-$\infty$ entities of type `body`

### **`occupant`**

**`{occupant}`** was transported using **`{vehicle}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{vehicle}`**: $0$-$\infty$ entities of type `vehicle`

### **`sentence`**

**`{court}`** court or judge sentenced **`{defendant}`** for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`start_position`**

**`{employee}`** started working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`threaten`**

**`{communicator}`** communicated (by any means) a threat, coersion, or provocation to **`{recipient}`** about **`{topic}`** topic.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`
