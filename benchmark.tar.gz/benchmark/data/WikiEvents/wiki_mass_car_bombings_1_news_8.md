## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`correspond`**

**`{participant}`** corresponded remotely with **`{participant}`**.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`defeat`**

In a conflict or election between **`{victor}`** and **`{loser}`**, **`{victor}`** was triumphant.
- **`{victor}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{loser}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{place}`** is the most specific given location where **`{victim}`** died.
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `information` | `payment` | `product` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`exchange`**

**`{giver}`** gave **`{entity}`** to **`{recipient}`** in exchange for **`{payment}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{entity}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `product` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{payment}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `product` | `vehicle` | `weapon`

### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{explosive}`**: $0$-$\infty$ entities of type `product` | `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage to or at **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `payment` | `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`identify`**

**`{identifier}`** identified **`{object}`** as **`{role}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{identifier}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{object}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{role}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `payment` | `product` | `vehicle` | `weapon`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`made_of`**

**`{artifact}`** is made of, or can be disassembled back into **`{components}`**.
- **`{artifact}`**: $1$-$1$ entities of type `facility` | `payment` | `product` | `vehicle` | `weapon`
- **`{components}`**: $1$-$\infty$ entities of type `product` | `vehicle` | `weapon`

### **`meet`**

**`{participant}`** met face-to-face with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic, and **`{place}`** is the most specific given location where this meeting occurred.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`move`**

**`{mover}`** moved from **`{origin}`** to **`{destination}`**.
- **`{mover}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`observe`**

**`{observer}`** used **`{instrument}`** to observe **`{entity}`**.
- **`{observer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `product`
- **`{entity}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `payment` | `person` | `product` | `vehicle` | `weapon`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`release`**

**`{defendant}`** was released or paroled by the judge or court **`{court}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`transport`**

**`{occupant}`** was transported from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
