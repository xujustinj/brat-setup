## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `title`

**`{title}`** is a person's title or job role

#### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`attempted_move`**

Someone attempted to move **`{mover}`** from **`{origin}`** to **`{destination}`**, successfully or unsuccessfully.
- **`{mover}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`correspond`**

**`{participant}`** corresponded remotely with **`{participant}`**.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`demonstrate`**

**`{demonstrator}`** supported **`{topic}`** in a demonstration against **`{target}`**.
- **`{demonstrator}`**: 0-∞ entities of type **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`dismantle`**

**`{dismantler}`** dismantled **`{artifact}`** into **`{components}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{dismantler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{components}`**: 0-∞ entities of type **`product`**
- **`{instrument}`**: 0-∞ entities of type **`product`** | **`vehicle`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`identify`**

**`{identifier}`** identified **`{object}`** as **`{role}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{identifier}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{object}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{role}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`injure`**

**`{injurer}`** injured **`{victim}`**.
- **`{injurer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{victim}`**: 0-∞ entities of type **`person`**

#### **`medical_intervention`**

**`{treater}`** treated **`{patient}`** for a medical issue, and **`{place}`** is the most specific given location where this occurred.
- **`{treater}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{patient}`**: 0-∞ entities of type **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`meet`**

**`{participant}`** met with **`{participant}`** at **`{place}`**.
- **`{participant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`move`**

**`{mover}`** moved from **`{origin}`** to **`{destination}`**.
- **`{mover}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`observe`**

**`{observer}`** used **`{instrument}`** to observe **`{entity}`**.
- **`{observer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`product`**
- **`{entity}`**: 0-∞ entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`occupant`**

**`{occupant}`** was transported using **`{vehicle}`**.
- **`{occupant}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{vehicle}`**: 0-∞ entities of type **`vehicle`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`value`** | **`vehicle`** | **`weapon`**

#### **`price`**

**`{price}`** is the monetary value used to purchase **`{artifact}`** in an exchange.
- **`{price}`**: 1-1 entities of type **`payment`**
- **`{artifact}`**: 1-∞ entities of type **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`transport`**

**`{occupant}`** was transported from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: 0-∞ entities of type **`body`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
