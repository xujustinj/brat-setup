## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`crime`**

**`{perpetrator}`** committed a crime against **`{victim}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{perpetrator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`destroy`**

**`{destroyer}`** destroyed **`{artifact}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{destroyer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`end_position`**

**`{employee}`** stopped working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`exchange`**

**`{giver}`** gave **`{entity}`** to **`{recipient}`** in exchange for **`{payment}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{entity}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `organization` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{payment}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `organization` | `vehicle` | `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage to or at **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `person` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`meet`**

**`{participant}`** met face-to-face with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic, and **`{place}`** is the most specific given location where this meeting occurred.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `person` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `person` | `vehicle` | `weapon`

### **`work`**

**`{employee}`** held the position of **`{position}`** at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity`
