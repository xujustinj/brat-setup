## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`convict`**

**`{court}`** court or judge convicted **`{defendant}`** of a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`detain`**

**`{detainee}`** was arrested or jailed by **`{jailer}`**.
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{killer}`** killed **`{victim}`**.
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `product` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`explode`**

**`{attacker}`** attacked **`{target}`** by exploding **`{explosive}`** using **`{instrument}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`
- **`{explosive}`**: $0$-$\infty$ entities of type `product` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `product` | `weapon`

### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle` | `weapon`

### **`injure`**

**`{injurer}`** used **`{instrument}`** to cause injury to **`{victim}`**.
- **`{injurer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{victim}`**: $0$-$\infty$ entities of type `person`

### **`made_of`**

**`{artifact}`** is made of, or can be disassembled back into **`{components}`**.
- **`{artifact}`**: $1$-$1$ entities of type `facility` | `product` | `vehicle` | `weapon`
- **`{components}`**: $1$-$\infty$ entities of type `product` | `vehicle` | `weapon`

### **`observe`**

**`{observer}`** used **`{instrument}`** to observe **`{entity}`**.
- **`{observer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `product`
- **`{entity}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `organization` | `person` | `product` | `vehicle` | `weapon`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `person` | `product` | `value` | `vehicle` | `weapon`
