## Entity Types

#### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

#### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

#### **`broadcast`**

**`{communicator}`** remotely broadcasted a one-way communication to **`{recipient}`** containing information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic using **`{instrument}`**.
- **`{communicator}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{recipient}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{topic}`**: 0-∞ entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{instrument}`**: 0-∞ entities of type **`information`** | **`product`**

#### **`charge`**

**`{defendant}`** was charged before **`{court}`** with a crime by **`{prosecutor}`**.
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{prosecutor}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`damage`**

**`{damager}`** damaged **`{artifact}`**, but did not destroy it.
- **`{damager}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`location`** | **`payment`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`detain`**

**`{jailer}`** arrested or jailed **`{detainee}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{jailer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{detainee}`**: 0-∞ entities of type **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: 0-∞ entities of type **`person`**
- **`{killer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`disable`**

**`{artifact}`** was defused or disabled by **`{disabler}`**.
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`information`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{disabler}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**

#### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{explosive}`**: 0-∞ entities of type **`product`** | **`weapon`**

#### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage at or towards **`{target}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`injure`**

**`{victim}`** was injured in **`{body_part}`** body part.
- **`{victim}`**: 0-∞ entities of type **`person`**
- **`{body_part}`**: 0-∞ entities of type 

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**

#### **`start_position`**

**`{employee}`** started working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: 0-∞ entities of type **`person`**
- **`{position}`**: 0-∞ entities of type 
- **`{employer}`**: 0-∞ entities of type **`entity`** | **`organization`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`transport`**

**`{transporter}`** transported themselves or **`{occupant}`** in **`{vehicle}`** from **`{origin}`** place to **`{destination}`** place.
- **`{transporter}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{occupant}`**: 0-∞ entities of type **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`** | **`weapon`**
- **`{vehicle}`**: 0-∞ entities of type **`vehicle`**
- **`{origin}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
- **`{destination}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**
