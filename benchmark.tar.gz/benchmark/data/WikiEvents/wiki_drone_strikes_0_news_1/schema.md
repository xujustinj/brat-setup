## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`attack`**

**`{attacker}`** used **`{instrument}`** to attack **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{instrument}`**: $0$-$\infty$ entities of type `vehicle` | `weapon`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `vehicle` | `weapon`

### **`communicate`**

**`{participant}`** communicated by any means (one-way or two-way) with **`{participant}`**.
- **`{participant}`**: $2$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`convict`**

**`{defendant}`** was convicted of a crime by **`{court}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`die`**

**`{victim}`** died of some affliction, or was killed by **`{killer}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{victim}`**: $0$-$\infty$ entities of type `person`
- **`{killer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `information` | `vehicle` | `weapon`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`explode`**

In an attack on **`{target}`** by **`{attacker}`**, **`{explosive}`** was exploded or detonated.
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `vehicle` | `weapon`
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{explosive}`**: $0$-$\infty$ entities of type `weapon`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage to or at **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `vehicle` | `weapon`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`investigate`**

**`{investigator}`** investigated **`{defendant}`** for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{investigator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `value` | `vehicle` | `weapon`

### **`research`**

**`{researcher}`** researched **`{subject}`**, and **`{place}`** is the most specific given location where the research occurred.
- **`{researcher}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{subject}`**: $0$-$\infty$ entities of type `body` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `person` | `value` | `vehicle` | `weapon`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
