## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

### `weapon`

**`{weapon}`** is a physical device that is primarily used as an instrument for physically harming or destroying entities

## Relation Types

### **`damage`**

**`{damager}`** damaged **`{artifact}`**, but did not destroy it.
- **`{damager}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `facility` | `location` | `payment` | `product` | `vehicle` | `weapon`

### **`demonstrate`**

**`{demonstrator}`** supported **`{topic}`** in a demonstration against **`{target}`**.
- **`{demonstrator}`**: $0$-$\infty$ entities of type `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`
- **`{target}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`detain`**

**`{detainee}`** was arrested or jailed by **`{jailer}`**.
- **`{detainee}`**: $0$-$\infty$ entities of type `person`
- **`{jailer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`discuss`**

**`{participant}`** communicated (by any means) with **`{participant}`** to discuss information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `information` | `location` | `organization` | `payment` | `person` | `product` | `value` | `vehicle` | `weapon`

### **`release`**

**`{defendant}`** was released or paroled by the judge or court **`{court}`**.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{court}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`transport`**

**`{occupant}`** was transported from **`{origin}`** to **`{destination}`**.
- **`{occupant}`**: $0$-$\infty$ entities of type `body` | `facility` | `location` | `payment` | `person` | `product` | `vehicle` | `weapon`
- **`{origin}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
- **`{destination}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
