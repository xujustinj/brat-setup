## Entity Types

#### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

#### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing

#### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

#### `entity`

**`{entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

#### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

#### `information`

**`{information}`** is an informational artifact, including digital or physical media, computer programs, intellectual property, fields of study, ideas, thoughts, opinions, beliefs, facts, data

#### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

#### `payment`

**`{payment}`** is a monetary payment, which includes quantifiers, the amount, and the currency unit, all of which can be optional.

#### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

#### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

#### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

## Relation Types

#### **`attack`**

**`{attacker}`** attacked **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where the attack occurred.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`person`** | **`product`** | **`vehicle`**
- **`{instrument}`**: 0-∞ entities of type **`product`** | **`vehicle`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`charge`**

**`{prosecutor}`** charged or indicted **`{defendant}`** before **`{court}`** court or judge for a crime, and **`{place}`** is the most specific given location where this occurred.
- **`{prosecutor}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{defendant}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{court}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`destroy`**

**`{destroyer}`** destroyed **`{artifact}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{destroyer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`location`** | **`payment`** | **`product`** | **`vehicle`**
- **`{instrument}`**: 0-∞ entities of type **`product`** | **`vehicle`**
- **`{place}`**: 0-1 entities of type **`entity`** | **`facility`** | **`location`**

#### **`exchange`**

**`{giver}`** gave **`{entity}`** to **`{recipient}`** in exchange for **`{payment}`**.
- **`{giver}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{entity}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`product`** | **`vehicle`**
- **`{recipient}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{payment}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`product`** | **`vehicle`**

#### **`explode`**

**`{attacker}`** used **`{instrument}`** to cause the explosion of **`{explosive}`**.
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{instrument}`**: 0-∞ entities of type **`product`**
- **`{explosive}`**: 0-∞ entities of type **`product`**

#### **`harm`**

**`{instrument}`** was used by **`{attacker}`** to cause, or attempt to cause damage or physical harm at or towards **`{target}`**.
- **`{instrument}`**: 0-∞ entities of type **`facility`** | **`payment`** | **`product`** | **`vehicle`**
- **`{attacker}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{target}`**: 0-∞ entities of type **`entity`** | **`facility`** | **`location`** | **`payment`** | **`person`** | **`product`** | **`vehicle`**

#### **`injure`**

**`{victim}`** was injured in **`{body_part}`** body part.
- **`{victim}`**: 0-∞ entities of type **`person`**
- **`{body_part}`**: 0-∞ entities of type **`body`**

#### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: 2-2 entities of type **`body`** | **`condition`** | **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`person`** | **`product`** | **`vehicle`**

#### **`price`**

**`{price}`** is the monetary value used to purchase **`{artifact}`** in an exchange.
- **`{price}`**: 1-1 entities of type **`payment`**
- **`{artifact}`**: 1-∞ entities of type **`entity`** | **`facility`** | **`information`** | **`location`** | **`organization`** | **`payment`** | **`product`** | **`vehicle`**

#### **`produce`**

**`{producer}`** manufactured, assembled, or produced **`{artifact}`**.
- **`{producer}`**: 0-∞ entities of type **`entity`** | **`organization`** | **`person`**
- **`{artifact}`**: 0-∞ entities of type **`facility`** | **`payment`** | **`product`** | **`vehicle`**
