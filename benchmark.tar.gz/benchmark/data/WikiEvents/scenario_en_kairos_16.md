## Entity Types

### `body`

**`{body}`** is an identifiable, living part or whole of a human's or animal's body, such as an eye, ear, neck, leg, etc.

### `product`

**`{product}`** is a tangible product or article of trade for which someone pays or barters, or more generally, an artifact or a thing.

### `facility`

**`{facility}`** is a facility: a functional, primarily man-made structure falling under the domains of architecture and civil engineering, including more temporary human constructs, such as police lines and checkpoints.

### `geopolitical_entity`

**`{geopolitical_entity}`** refers to (by name, pronoun, or denonym), a geopolitical entity (GPE) or group of GPEs (such as countries, provinces, states, cities, towns, etc.), each one consisting of a physical location, a government, and a population.

### `condition`

**`{condition}`** refers to a (specific, group of, or generic) medical condition or health issue, including everything from disease to broken bones to fever to general ill health, medical errors, even natural causes.

### `location`

**`{location}`** refers to (by name or pronoun), a geographical entity such as geographical areas and landmasses, or bodies of water, but which is not a geopolitical entity (such as countries, provinces, states, cities, towns, etc.), or a facility (human-constructed physical structure).

### `organization`

**`{organization}`** refers to (by name or pronoun), a corporation, agency, or other group of people defined by an established organizational structure, which can change members without changing identity.

### `person`

**`{person}`** refers to (by name or pronoun, excluding honorifics), a single human person or a group of people, but not an organization (corporation, agency, or other group of people defined by an established organizational structure).

### `title`

**`{title}`** is a person's title or job role

### `value`

**`{value}`** is a numerical value, or non-numerical value such as an informational property like color, make, or URL.

### `vehicle`

**`{vehicle}`** is a physical device primarily designed to move an object from one location to another, by (for example) carrying, flying, pulling, or pushing the transported object.

## Relation Types

### **`attack`**

**`{attacker}`** attacked **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle`

### **`broadcast`**

**`{communicator}`** remotely broadcasted a one-way communication to **`{recipient}`** containing information (excluding requests, commands, orders, threats, coersions, or provocations) about **`{topic}`** topic using **`{instrument}`**.
- **`{communicator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{topic}`**: $0$-$\infty$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `person` | `product` | `value` | `vehicle`
- **`{instrument}`**: $0$-$\infty$ entities of type `product`

### **`correspond`**

**`{participant}`** corresponded remotely with **`{participant}`**.
- **`{participant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`donate`**

**`{giver}`** donated **`{artifact}`** to **`{recipient}`**.
- **`{giver}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{artifact}`**: $0$-$\infty$ entities of type `body` | `facility` | `product` | `vehicle`
- **`{recipient}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`explode`**

Explosives were exploded or detonated by **`{attacker}`**, in an attack targeting **`{target}`**.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle`

### **`harm`**

**`{attacker}`** caused, or attempted to cause physical harm or damage to or at **`{target}`** using **`{instrument}`**, and **`{place}`** is the most specific given location where this occurred.
- **`{attacker}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{target}`**: $0$-$\infty$ entities of type `facility` | `geopolitical_entity` | `location` | `person` | `product` | `vehicle`
- **`{instrument}`**: $0$-$\infty$ entities of type `facility` | `product` | `vehicle`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`

### **`investigate`**

**`{defendant}`** was investigated by **`{investigator}`** for a crime.
- **`{defendant}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`
- **`{investigator}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization` | `person`

### **`opposite`**

**`{side}`** and **`{side}`** are explicitly opposite one another in some past or current conflict (ideological, military, political, legal, physical, athletic, etc.).
- **`{side}`**: $2$-$2$ entities of type `body` | `condition` | `facility` | `geopolitical_entity` | `location` | `organization` | `person` | `product` | `value` | `vehicle`

### **`start_position`**

**`{employee}`** started working in **`{position}`** position at **`{employer}`** organization, and **`{place}`** was the most specific given location of their work.
- **`{employee}`**: $0$-$\infty$ entities of type `person`
- **`{position}`**: $0$-$\infty$ entities of type `title`
- **`{employer}`**: $0$-$\infty$ entities of type `geopolitical_entity` | `organization`
- **`{place}`**: $0$-$1$ entities of type `facility` | `geopolitical_entity` | `location`
